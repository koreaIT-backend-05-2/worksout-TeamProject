package com.project.worksout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorksoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
