const signupBtn = document.querySelector(".signup-button");

signupBtn.onclick = () => {
    location.href = "/signup";
}