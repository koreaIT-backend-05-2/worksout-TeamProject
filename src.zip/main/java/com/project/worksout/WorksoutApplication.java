package com.project.worksout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorksoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorksoutApplication.class, args);
	}

}
